---
layout: concert
categories: performance
date: 2011-08-16
event: Anna Kijanowska, LaSalle School of Contemporary Music
describe: Singapore premiere of <em>Karttikeya (Study No. 1)</em> with pianist Anna Kijanowska. LaSalle School of Contemporary Music, Singapore.
location:
  institution: LaSalle School of Contemporary Music
  venue: LaSalle School of Contemporary Music
  address:
  city: Singapore
  state:
  zip:
  country: Singapore
program:
  - composer: Jason Thorpe Buchanan
    title: Karttikeya (Study No. 1)
thumbnail:  
tags:
  - older
  - piano
  - singapore
---
