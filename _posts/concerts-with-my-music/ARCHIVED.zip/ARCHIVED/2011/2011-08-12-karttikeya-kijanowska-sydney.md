---
layout: concert
categories: performance
date: 2011-08-12
event: Anna Kijanowska, Consulate General of the Republic of Poland, Sydney, Australia
describe: Australian premiere of <em>Karttikeya (Study No. 1)</em> with pianist Anna Kijanowska. Consulate General of the Republic of Poland, Sydney, Australia.
location:
  institution: Consulate General of the Republic of Poland
  venue: Consulate General of the Republic of Poland
  address:
  city: Sydney
  state:
  zip:
  country: Australia
program:
  - composer: Jason Thorpe Buchanan
    title: Karttikeya (Study No. 1)
thumbnail:  
tags:
  - older
  - piano
  - sydney
  - australia
---
