---
layout: concert
categories: performance
date: 2011-10-13
event: Eastman Composers' Forum
describe: American premiere of <em>Berlin Songs</em> and Rochester premiere of Christopher Chandler's <em>The Resonance After</em>, Jason Thorpe Buchanan, conductor.
location:
  institution: Eastman School of Music
  venue: Kilbourn Hall
  address:
  city: Rochester
  state: NY
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Berlin Songs
  - composer: Christopher Chandler
    title: The Resonance After
thumbnail:  
tags:
  - older
  - eastman
  - ensemble
---
