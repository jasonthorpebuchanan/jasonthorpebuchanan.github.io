---
layout: concert
categories: performance
date: 2011-08-18
event: Anna Kijanowska, Yong Siew Toh Conservatory of Music
describe: <em>Karttikeya (Study No. 1)</em> with pianist Anna Kijanowska. Yong Siew Toh Conservatory of Music, Singapore.
location:
  institution: Yong Siew Toh Conservatory of Music
  venue: Yong Siew Toh Conservatory of Music
  address:
  city: Singapore
  state:
  zip:
  country: Singapore
program:
  - composer: Jason Thorpe Buchanan
    title: Karttikeya (Study No. 1)
thumbnail:  
tags:
  - older
  - piano
  - singapore
---
