---
layout: concert
categories: performance
date: 2011-03-22
event: Fulbright Pan-European Conference and Gala Concert
describe: World premiere of <em>Berlin Songs</em> with Fulbright Musicians and Thomas Heuser, conductor. Fulbright Pan-European Conference and Gala Concert, Akademie der Künste, Berlin, Germany.
location:
  institution: Akademie der Künste
  venue: Akademie der Künste
  address:
  city: Berlin
  state:
  zip:
  country: Germany
program:
  - composer: Jason Thorpe Buchanan
    title: Berlin Songs
thumbnail:  
tags:
  - older
  - fulbright
  - ensemble
  - berlin
  - germany
---
