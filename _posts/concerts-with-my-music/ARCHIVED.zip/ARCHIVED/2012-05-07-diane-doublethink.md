---
layout: concert
describe: "Rochester premiere of <em>First Study for Alto Saxophone: doublethink</em> (2012), Diane Hunger, saxophone. Rest is Noise Concert, The Little Theatre, Rochester, NY."
date: 2012-05-07
categories: performance
event: Rest is Noise Concert
location:
  building:
  venue: The Little Theatre
  address:
  city: Rochester
  state: NY
  zip: 14604
program:
  - composer: Jason Thorpe Buchanan
    title: "First Study for Alto Saxophone: doublethink"
    year: 2012
thumbnail:
photosFolder:
tags:
  - older
  - rest is noise
  - saxophone
---

May.07.2012: Rochester premiere of <em>First Study for Alto Saxophone: doublethink</em> with Diane Hunger, saxophone. Rest is Noise Concert, The Little Theatre, Rochester, NY.
