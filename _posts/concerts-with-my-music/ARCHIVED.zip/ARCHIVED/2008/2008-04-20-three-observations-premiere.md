---
layout: concert
categories: performance
date: 2008-04-20
event: Michael Walker Senior Horn Recital
describe: World premiere of <em>Three Observations</em> for Horn and Electronics. Michael Walker, senior horn recital. San Jose State University, CA.
location:
  institution: San Jose State University
  venue: School of Music
  address:
  city: San Jose
  state: CA
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Three Observations for Horn and Electronics
thumbnail:  
tags:
  - older
  - horn
  - electronics
---
