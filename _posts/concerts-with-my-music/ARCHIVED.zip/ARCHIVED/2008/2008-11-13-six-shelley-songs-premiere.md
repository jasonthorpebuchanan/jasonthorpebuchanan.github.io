---
layout: concert
categories: performance
date: 2008-11-13
event: Nicole Yazolino Master's Voice Recital
describe: World premiere of <em>Six Shelley Songs</em> for soprano and piano. Nicole Yazolino, senior voice recital. Cincinnati Conservatory of Music, OH.
location:
  institution: Cincinnati Conservatory of Music
  venue: Cincinnati Conservatory of Music
  address:
  city: Cincinnati
  state: OH
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Six Shelley Songs
thumbnail:  
tags:
  - older
  - voice
  - soprano
  - piano
  - cincinnati
---
