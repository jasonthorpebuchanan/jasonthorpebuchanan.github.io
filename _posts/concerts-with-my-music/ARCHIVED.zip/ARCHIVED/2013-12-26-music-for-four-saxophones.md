---
layout: concert
describe: "<em>Music for Four Saxophones: One (In Stasis)</em> (2009). Northwest Wind Symphony, Dan Schmidt, conductor."
date: 2013-12-26
categories: performance
event:
location:
  building:
  venue:
  address:
  city: Centralia
  state: WA
program:
  - composer: Jason Thorpe Buchanan
    title: "Music for Four Saxophones: One (In Stasis)"
    year: 2009
thumbnail: updates/oggetti_5.jpg
photosFolder:
tags:
  - older
---
