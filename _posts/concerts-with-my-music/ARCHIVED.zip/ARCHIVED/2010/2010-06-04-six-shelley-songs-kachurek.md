---
layout: concert
categories: performance
date: 2010-06-04
event: Melos New Music Concert, Chicago
describe: <em>Six Shelley Songs</em> for soprano and piano. Laura Kachurek, soprano. Chicago, IL.
location:
  institution:
  venue: PianoForte
  address:
  city: Chicago
  state: IL
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Six Shelley Songs
thumbnail: updates/meloschicago250.jpg
tags:
  - older
  - voice
  - soprano
  - piano
  - chicago
---
