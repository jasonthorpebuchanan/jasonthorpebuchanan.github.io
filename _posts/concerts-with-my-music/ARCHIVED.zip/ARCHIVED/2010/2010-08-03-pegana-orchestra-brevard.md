---
layout: concert
categories: performance
date: 2010-08-03
event: Brevard Music Center Orchestra, Reading Session
describe: Reading Session, <em>The Gods of Pegana</em>. Brevard Music Center Orchestra, Ken Lam, conductor.
location:
  institution:
  venue: Brevard
  address:
  city: Brevard
  state: NC
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: The Gods of Pegana
thumbnail:  
tags:
  - older
  - orchestra
---
