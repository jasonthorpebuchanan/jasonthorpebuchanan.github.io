---
layout: concert
categories: performance
date: 2009-03-11
event: Cristina Valdes, guest artist
describe: World premiere of <em>Karttikeya (Study No. 1)</em> for solo piano. Winner of University of Nevada, Las Vegas Piano Composition Competition. Cristina Valdes, piano. Las Vegas, NV
location:
  institution: University of Nevada, Las Vegas
  venue: University of Nevada, Las Vegas
  address:
  city: Las Vegas
  state: NV
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Karttikeya (Study No. 1)
thumbnail:  
tags:
  - older
  - piano
  - las vegas
media:
  - title: "Karttikeya (Study No. 1) by Jason Thorpe Buchanan"
    url:  https://www.youtube.com/embed/xi3z4L61bj8
---
