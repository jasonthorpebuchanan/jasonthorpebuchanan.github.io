---
layout: concert
categories: performance
date: 2009-08-02
event: Brevard Music Center Orchestra, Reading Session
describe: Reading Session, <em>Orchestral Sketch No. 1</em>. Brevard Music Center Orchestra, Ken Lam, conductor.
location:
  institution:
  venue: Brevard
  address:
  city: Brevard
  state: NC
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Orchestral Sketch No. 1
thumbnail:  
tags:
  - older
  - orchestra
---
