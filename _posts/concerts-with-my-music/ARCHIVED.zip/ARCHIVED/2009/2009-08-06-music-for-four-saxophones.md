---
layout: concert
categories: performance
date: 2009-08-06
event: Brevard ITCH New Music Concert
describe: World premiere of <em>Music for Four Saxophones (In Stasis)</em>. Brevard Music Center, ITCH New Music Concert.
location:
  institution:
  venue: Brevard
  address:
  city: Brevard
  state: NC
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Music for Four Saxophones (In Stasis)
thumbnail:  
tags:
  - older
  - sax
---
