---
layout: concert
categories: performance
date: 2009-05-01
event: UNLV Brass Ensemble
describe: World premiere of <em>Vasava (Lord of the Spheres)</em>. UNLV Brass Ensemble, Jason Thorpe Buchanan, conductor.
location:
  institution:
  venue: University of Nevada, Las Vegas
  address:
  city: Las Vegas
  state: NV
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Vasava (Lord of the Spheres)
thumbnail:  
tags:
  - older
  - brass
---
