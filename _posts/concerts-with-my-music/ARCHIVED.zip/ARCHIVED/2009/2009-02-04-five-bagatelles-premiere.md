---
layout: concert
categories: performance
date: 2009-02-04
event: Nextet Concert
describe: World premiere of <em>Five Bagatelles</em> for horn and marimba. Ryan Simm and Bryce Nakaoka, UNLV, Las Vegas, NV
location:
  institution: University of Nevada, Las Vegas
  venue: University of Nevada, Las Vegas
  address:
  city: Las Vegas
  state: NV
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Five Bagatelles for Horn and Marimba
thumbnail:  
tags:
  - older
  - horn
  - marimba
  - las vegas
---
