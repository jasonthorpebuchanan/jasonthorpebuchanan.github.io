---
layout: concert
categories: performance
date: 2009-06-11
event: Tad Wind Symphony Concert
describe: World premiere of <em>A Zarzuela & Other Lost Works</em> for wind ensemble. Tad Wind Symphony, Takayoshi Suzuki, conductor. Tokyo, Japan.
location:
  institution:
  venue:
  address:
  city: Tokyo
  state:
  zip:
  country: Japan
program:
  - composer: Jason Thorpe Buchanan
    title: A Zarzuela & Other Lost Works
thumbnail:  
tags:
  - older
  - wind symphony
  - japan
---
