---
layout: concert
categories: performance
date: 2009-04-08
event: N.E.O.N. Music Festival
describe: World premiere of <em>Songs of Moonlight & Shadows</em> soprano and ensemble. Jorge Grossmann, conductor. University of Nevada, Las Vegas.
location:
  institution: University of Nevada, Las Vegas
  venue: University of Nevada, Las Vegas
  address:
  city: Las Vegas
  state: NV
  zip:
program:
  - composer: Jason Thorpe Buchanan
    title: Songs of Moonlight & Shadows
thumbnail:  
tags:
  - older
  - soprano
  - voice
  - las vegas
---
