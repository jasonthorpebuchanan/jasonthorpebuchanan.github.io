---
layout: post
title: "Bogliasco Fellowship"
date: 2024-03-29
categories: news
headerImage: updates/2024/bogliasco_560.jpg
thumbnail: updates/2024/bogliasco_560.jpg
500pxImage: updates/2024/bogliasco_560.jpg
photosFolder: Babel
postDescription: "I'm thrilled to have been awarded a 2024 Bogliasco Fellowship, where I will spend November-December composing as an Artist-in-Residence at their Study Center on the coast of Genoa, Italy."
tags:
  - 2024
  - air
  - news
---

"I'm thrilled to have been awarded a 2024 Bogliasco Fellowship, where I will spend November-December as an Artist-in-Residence at their Study Center on the coast of Genoa, Italy. https://www.bfny.org/en/home
