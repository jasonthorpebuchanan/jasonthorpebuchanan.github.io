---
layout: concert
categories: conducting
date: 2012-11-19
event: Eastman Graduate Composers' Sinfonietta
describe: "Conducting the world premieres of <em>Cronica de una vuelta</em> by Theocharis Papatrechas and <em>Octamerism</em> by Nathaniel Stang, Eastman Graduate Composers' Sinfonietta."
location:
  institution: Eastman School of Music
  venue: Ray Wright Room
  address: 26 Gibbs St.
  city: Rochester
  state: NY
  zip: 14604
program:
  - composer: Theocharis Papatrechas
    title: Cronica de una vuelta
  - composer: Nathaniel Stang
    title: Octamerism
thumbnail:  
tags:
  - older
  - eastman graduate composers sinfonietta
  - conducting
---


http://www.youtube.com/watch?v=nrHo3QqF2Pk

http://www.jasonthorpebuchanan.com/ecmclillios.png
