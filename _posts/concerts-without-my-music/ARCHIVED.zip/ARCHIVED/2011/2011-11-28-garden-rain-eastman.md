---
layout: concert
categories: performance
date: 2011-11-28
event: OSSIA New Music Concert
describe: Conducting <em>Garden Rain</em> by Toru Takemitsu.
location:
  institution: Eastman School of Music
  venue: Kilbourn Hall
  address:
  city: Rochester
  state: NY
  zip:
program:
  - composer: Toru Takemitsu
    title: Garden Rain
thumbnail:  
tags:
  - older
  - eastman
  - ensemble
  - conducting
---
