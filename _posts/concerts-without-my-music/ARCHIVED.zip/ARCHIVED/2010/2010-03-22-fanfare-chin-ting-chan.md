---
layout: concert
categories: performance
date: 2010-03-22
event: UNLV Brass Ensemble Concert
describe: Conducting <em>Fanfare for Brass and Percussion</em> by Chin Ting Chan, world premiere. UNLV Brass Ensemble.
location:
  institution: UNLV
  venue:
  address:
  city: Las Vegas
  state: NV
  zip:
program:
  - composer: Chin Ting Chan
    title: Fanfare for Brass and Percussion
thumbnail:  
tags:
  - older
  - unlv
  - ensemble
  - conducting
---
