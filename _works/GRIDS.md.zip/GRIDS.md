---
composer:
  first: Jason
  last: Thorpe Buchanan
title: "GRIDS"
duration: 25 minutes
yearComposed: 2025
commissionedOrWrittenFor: "Commissioned by EMPAC"
size: septet, video
instrumentation:
  - septet
  - feedback instruments
  - sensors
  - video
  - audiovisual processing system
tags:
  - electronics
  - video
media:
- title: 
  url: 
score: score_GRIDS.html
headerImage: works-images/grids-feb-workshop_640x360.jpg
portWrapper: works-images/port-wrapper/EoD_LUL_640x360.jpg
photosFolder: GRIDS
purchase: "Perusal PDF Score: $20; Score and Parts: $160"
contact: jasontbuchanan[at]gmail.com
awards: "Commissioned by EMPAC"
dedication: "For the [Switch~ Ensemble]"
premiere: "EMPAC, Troy, NY, September 12, 2025"   


---
*GRIDS* (2025) is a collaborative work with Christopher Chandler and the [Switch~ Ensemble]. More info coming soon...

